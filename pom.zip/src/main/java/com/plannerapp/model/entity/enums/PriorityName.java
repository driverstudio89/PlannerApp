package com.plannerapp.model.entity.enums;

public enum PriorityName {
    URGENT, IMPORTANT, LOW
}
